Em conjunto somos melhores
